Welcome to Shoot Shoot Pow Pow, A game created by Nathan Bhat.

The point of the game is to throw your spear and hit the other player(s).
Each player has 3 lives.
The last one standing wins!

Play among 9 different levels, with up to 4 players.

This game supports keyboards with numpads and gamepads.

You can find an infographic of the controls in the pause menu at any time in the game.

Advanced move: When you aren't holding a spear, if you press the jump button while in the air, plus a direction, you will perform an air dodge in that direction.

This is version 1.0